package com.example.miaplicacion;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView TvResultado;
    EditText EtNum1,EtNum2;
    Button BtSumar,BtRestar,BtMulti,BtDividir;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TvResultado=findViewById(R.id.tv_resultado);   //buscar por el id puesto en el xml
         EtNum1=findViewById(R.id.et_num1);
        EtNum2=findViewById(R.id.et_num2);
        BtSumar=findViewById(R.id.btn_suma);
        BtRestar=findViewById(R.id.btn_resta);
        BtMulti=findViewById(R.id.btn_multiplicar);
        BtDividir=findViewById(R.id.btn_dividir);

    }
}