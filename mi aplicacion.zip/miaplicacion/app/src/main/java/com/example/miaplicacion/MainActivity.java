package com.example.miaplicacion;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView TvResultado;
    EditText EtNum1,EtNum2;
    Button BtSumar,BtRestar,BtMulti,BtDividir;



    public void onClick(View view) {
        // Obtener los números ingresados como strings
        String num1Str = EtNum1.getText().toString();
        String num2Str = EtNum2.getText().toString();

        if (num1Str.isEmpty() || num2Str.isEmpty()) {
            Toast.makeText(this, "Coloca los números", Toast.LENGTH_SHORT).show();
            return;
        // Convertir los números a valores numéricos
        double num1 = Double.parseDouble(num1Str);
        double num2 = Double.parseDouble(num2Str);

        // Realizar la suma
        double resultado = num1 + num2;

        // Mostrar el resultado en el TextView
        TvResultado.setText("Resultado: " + resultado);
        EtNum1.setText("");
        EtNum2.setText("");
    }
    public void clickRestaa(View view) {
        // Obtener los números ingresados como strings
        String num1Str = EtNum1.getText().toString();
        String num2Str = EtNum2.getText().toString();
            if (num1Str.isEmpty() || num2Str.isEmpty()) {
                Toast.makeText(this, "Coloca los números", Toast.LENGTH_SHORT).show();
                return;
        // Convertir los números a valores numéricos
        double num1 = Double.parseDouble(num1Str);
        double num2 = Double.parseDouble(num2Str);

        // Realizar la suma
        double resultado = num1 - num2;

        // Mostrar el resultado en el TextView
        TvResultado.setText("Resultado: " + resultado);
        EtNum1.setText("");
        EtNum2.setText("");
    }




    public void clickMulti(View view) {
        // Obtener los números ingresados como strings
        String num1Str = EtNum1.getText().toString();
        String num2Str = EtNum2.getText().toString();
                if (num1Str.isEmpty() || num2Str.isEmpty()) {
                    Toast.makeText(this, "Coloca los números", Toast.LENGTH_SHORT).show();
                    return;
        // Convertir los números a valores numéricos
        double num1 = Double.parseDouble(num1Str);
        double num2 = Double.parseDouble(num2Str);

        // Realizar la suma
        double resultado = num1 * num2;

        // Mostrar el resultado en el TextView
        TvResultado.setText("Resultado: " + resultado);
        EtNum1.setText("");
        EtNum2.setText("");
    }

    public void clickDiv(View view) {
        // Obtener los números ingresados como strings
        String num1Str = EtNum1.getText().toString();
        String num2Str = EtNum2.getText().toString();
                    if (num1Str.isEmpty() || num2Str.isEmpty()) {
                        Toast.makeText(this, "Coloca los números", Toast.LENGTH_SHORT).show();
                        return;
        // Convertir los números a valores numéricos
        double num1 = Double.parseDouble(num1Str);
        double num2 = Double.parseDouble(num2Str);

        // Realizar la suma
        double resultado = num1 / num2;

        // Mostrar el resultado en el TextView
        TvResultado.setText("Resultado: " + resultado);
        EtNum1.setText("");
        EtNum2.setText("");
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TvResultado=findViewById(R.id.tv_resultado);   //buscar por el id puesto en el xml
         EtNum1=findViewById(R.id.et_num1);
        EtNum2=findViewById(R.id.et_num2);
        BtSumar=findViewById(R.id.btn_suma);
        BtRestar=findViewById(R.id.btn_resta);
        BtMulti=findViewById(R.id.btn_multiplicar);
        BtDividir=findViewById(R.id.btn_dividir);



    }
}